export type FAQ = {
  id: string;
  category: string;
  question: string;
  answer: string;
  keywords: string[];
  actionType: "none" | "phone" | "reservation" | "link";
  actionLabel?: string;
  actionUrl?: string;
  isPublished: boolean;
  updatedAt: string;
  sortOrder?: number;
};

export type ClinicInfo = {
  clinicName: string;
  doctorName: string;
  departments: string;
  address: string;
  phone: string;
  openingHours: string;
  closedDays: string;
  access: string;
  parking: string;
  reservationUrl: string;
  websiteUrl: string;
  firstVisitRequirements: string;
  paymentMethods: string;
  feverInstructions: string;
};

export type ChatSettings = {
  mainColor: string;
  welcomeMessage: string;
  disclaimer: string;
  fallbackMessage: string;
  showPhoneButton: boolean;
  showReservationButton: boolean;
  showCharacter: boolean;
};

export type ChatRole = "user" | "bot";

export type MessageAction = {
  type: "phone" | "reservation" | "link" | "topic";
  label: string;
  url?: string;
};

export type ChatMessage = {
  id: string;
  role: ChatRole;
  text: string;
  timestamp: string;
  matchedFaqId?: string;
  matchedFaqQuestion?: string;
  answered: boolean;
  action?: MessageAction;
};

export type SalesDemoSettings = {
  clinicName: string;
  doctorName: string;
  departments: string;
  phone: string;
  address: string;
  reservationUrl: string;
  mainColor: string;
  logoUrl: string;
  salesMemo: string;
};

export type UnansweredStatus = "unreviewed" | "reviewing" | "faq_added" | "ignored";

export type UnansweredQuestion = {
  id: string;
  question: string;
  timestamp: string;
  status: UnansweredStatus;
};
