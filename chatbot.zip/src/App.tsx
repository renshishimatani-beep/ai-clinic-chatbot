import { useEffect, useState, useCallback } from "react";
import { MessageCircle, Settings, Monitor, LogOut, Loader2, Building2, ChevronDown } from "lucide-react";
import { useEmbedMode } from "@/hooks/useEmbedMode";
import type { FAQ, ClinicInfo, ChatSettings, ChatMessage, UnansweredQuestion } from "@/types";
import { storage, uid } from "@/services/storage";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";
import { getCurrentSession, signOut, onAuthChange } from "@/services/authService";
import { fetchMemberClinics, fetchClinicInfoById, fetchClinicInfoBySlug, type Clinic } from "@/services/clinicRepository";
import { fetchFaqsByClinicId, fetchFaqsBySlug } from "@/services/faqRepository";
import { fetchChatSettingsById, fetchChatSettingsBySlug } from "@/services/chatSettingsRepository";
import { ChatPage } from "@/pages/ChatPage";
import { AdminPage } from "@/pages/AdminPage";
import { SitePreviewPage } from "@/pages/SitePreviewPage";
import { EmbedPage } from "@/pages/EmbedPage";
import { LoginPage } from "@/pages/LoginPage";
import { SalesDemoBar } from "@/components/SalesDemoBar";
import { PresentationMode } from "@/components/PresentationMode";
import { SalesDemoSettingsModal } from "@/components/SalesDemoSettingsModal";
import { getSalesDemoSettings, setSalesDemoSettings } from "@/services/salesDemoStorage";
import type { SalesDemoSettings } from "@/types";
import { SAMPLE_FAQS, DEFAULT_SETTINGS, SAMPLE_CLINIC_INFO } from "@/data/sampleData";
import type { Session, User } from "@supabase/supabase-js";

type View = "chat" | "admin" | "preview";

type DemoSection = "dashboard" | "analytics" | "report";
const DEMO_STEP_SECTIONS: DemoSection[] = ["dashboard", "analytics", "report"];

const FALLBACK_SLUG = "tsunamaru-test";

function parseHashRoute(): { route: string; slug: string | null } {
  const hash = window.location.hash.replace(/^#\/?/, "");
  const parts = hash.split("/");
  if (parts[0] === "admin" && parts[1] === "login") return { route: "admin/login", slug: null };
  if (parts[0] === "admin") return { route: "admin", slug: null };
  if (parts[0] === "chat" && parts[1]) return { route: "chat", slug: parts[1] };
  if (parts[0] === "preview" && parts[1]) return { route: "preview", slug: parts[1] };
  if (parts[0] === "embed" && parts[1]) return { route: "embed", slug: parts[1] };
  if (parts[0] === "embed") return { route: "embed", slug: null };
  return { route: "", slug: null };
}

export default function App() {
  const isEmbed = useEmbedMode();
  const [view, setView] = useState<View>("chat");
  const [faqs, setFaqs] = useState<FAQ[]>(() => {
    storage.migrateIfNeeded();
    return storage.getFAQs();
  });
  const [clinicInfo, setClinicInfo] = useState<ClinicInfo>(() => storage.getClinicInfo());
  const [settings, setSettings] = useState<ChatSettings>(() => storage.getSettings());
  const [history, setHistory] = useState<ChatMessage[]>(() => storage.getHistory());
  const [unanswered, setUnanswered] = useState<UnansweredQuestion[]>(() => storage.getUnanswered());
  const [demoActive, setDemoActive] = useState(false);
  const [demoStep, setDemoStep] = useState(0);
  const [demoAdminSection, setDemoAdminSection] = useState<DemoSection>("dashboard");
  const [demoSettingsOpen, setDemoSettingsOpen] = useState(false);
  const [demoSettings, setDemoSettings] = useState<SalesDemoSettings>(() => getSalesDemoSettings());
  const [presentationMode, setPresentationMode] = useState(false);

  // Auth state
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [clinics, setClinics] = useState<Clinic[]>([]);
  const [selectedClinic, setSelectedClinic] = useState<Clinic | null>(null);
  const [clinicLoading, setClinicLoading] = useState(false);
  const [clinicError, setClinicError] = useState("");

  // Route state
  const [hashRoute, setHashRoute] = useState(() => parseHashRoute());

  // Sync hash route
  useEffect(() => {
    function onHashChange() {
      setHashRoute(parseHashRoute());
    }
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  // Init auth session
  useEffect(() => {
    if (!isSupabaseConfigured) {
      setAuthLoading(false);
      return;
    }
    (async () => {
      const { session } = await getCurrentSession();
      setUser(session?.user ?? null);
      setAuthLoading(false);
    })();
    const unsubscribe = onAuthChange((session: Session | null) => {
      setUser(session?.user ?? null);
    });
    return unsubscribe;
  }, []);

  // Load clinics when user logs in
  const loadClinics = useCallback(async () => {
    if (!user) return;
    setClinicLoading(true);
    setClinicError("");
    const { data, error } = await fetchMemberClinics();
    setClinicLoading(false);
    if (error) {
      setClinicError(error);
      return;
    }
    if (data && data.length > 0) {
      setClinics(data);
      if (data.length === 1) {
        setSelectedClinic(data[0]);
      }
    }
  }, [user]);

  useEffect(() => {
    if (user) loadClinics();
    else {
      setClinics([]);
      setSelectedClinic(null);
    }
  }, [user, loadClinics]);

  // Load clinic data from Supabase when clinic is selected
  const loadClinicData = useCallback(async (clinicId: string) => {
    setClinicLoading(true);
    setClinicError("");
    const [infoResult, faqResult, settingsResult] = await Promise.all([
      fetchClinicInfoById(clinicId),
      fetchFaqsByClinicId(clinicId),
      fetchChatSettingsById(clinicId),
    ]);
    setClinicLoading(false);
    if (infoResult.error) {
      setClinicError(infoResult.error);
      return;
    }
    if (infoResult.data) {
      const merged = { ...SAMPLE_CLINIC_INFO, ...infoResult.data };
      setClinicInfo(merged);
      storage.setClinicInfo(merged);
    }
    if (faqResult.data) {
      setFaqs(faqResult.data);
      storage.setFAQs(faqResult.data);
    }
    if (settingsResult.data) {
      const merged = { ...DEFAULT_SETTINGS, ...settingsResult.data };
      setSettings(merged);
      storage.setSettings(merged);
    }
  }, []);

  useEffect(() => {
    if (user && selectedClinic) {
      loadClinicData(selectedClinic.id);
    }
  }, [user, selectedClinic, loadClinicData]);

  // Load public data by slug for slug routes
  const loadPublicData = useCallback(async (slug: string) => {
    if (!isSupabaseConfigured) return;
    const [infoResult, faqResult, settingsResult] = await Promise.all([
      fetchClinicInfoBySlug(slug),
      fetchFaqsBySlug(slug),
      fetchChatSettingsBySlug(slug),
    ]);
    if (infoResult.data) {
      setClinicInfo({ ...SAMPLE_CLINIC_INFO, ...infoResult.data });
    }
    if (faqResult.data) {
      setFaqs(faqResult.data);
    }
    if (settingsResult.data) {
      setSettings({ ...DEFAULT_SETTINGS, ...settingsResult.data });
    }
  }, []);

  useEffect(() => {
    if (hashRoute.route === "chat" && hashRoute.slug) {
      loadPublicData(hashRoute.slug);
    } else if (hashRoute.route === "preview" && hashRoute.slug) {
      loadPublicData(hashRoute.slug);
    } else if (hashRoute.route === "embed" && hashRoute.slug) {
      loadPublicData(hashRoute.slug);
    }
  }, [hashRoute, loadPublicData]);

  async function handleLogout() {
    await signOut();
    setUser(null);
    setSelectedClinic(null);
    setClinics([]);
    window.location.hash = "#/admin/login";
  }

  function startSalesDemo() {
    if (!confirm("商談デモを開始しますか？\nデモデータは2026年8月にリセットされます。\nクリニック設定・FAQ・会話履歴は保持されます。")) return;
    setDemoStep(0);
    setDemoAdminSection("dashboard");
    setDemoActive(true);
    setView("admin");
    window.scrollTo(0, 0);
  }

  function saveDemoSettings(s: SalesDemoSettings) {
    setDemoSettings(s);
    setSalesDemoSettings(s);
  }

  const demoClinicInfo: ClinicInfo = demoActive
    ? { ...clinicInfo, ...demoSettings }
    : clinicInfo;
  const demoChatSettings: ChatSettings = demoActive
    ? { ...settings, mainColor: demoSettings.mainColor }
    : settings;

  function handleDemoStepChange(step: number) {
    setDemoStep(step);
    if (step <= 2) {
      setDemoAdminSection(DEMO_STEP_SECTIONS[step]);
      setView("admin");
    } else {
      setView("preview");
    }
    window.scrollTo(0, 0);
  }

  function exitSalesDemo() {
    setDemoActive(false);
    setPresentationMode(false);
    setView("admin");
  }

  function exitPresentation() {
    if (document.fullscreenElement) {
      document.exitFullscreen?.().catch(() => {});
    }
    setPresentationMode(false);
  }

  // Apply main color to CSS variable so non-Tailwind styles can use it
  useEffect(() => {
    document.documentElement.style.setProperty("--main-color", settings.mainColor || "#3BA9D4");
  }, [settings.mainColor]);

  function handleUnanswered(question: string) {
    const next = [
      {
        id: uid(),
        question,
        timestamp: new Date().toISOString(),
        status: "unreviewed" as const,
      },
      ...unanswered,
    ];
    setUnanswered(next);
    storage.setUnanswered(next);
  }

  function handleResetConversation() {
    if (!confirm("会話をリセットしますか？現在のチャットメッセージがすべて削除されます。")) return;
    setHistory([]);
    storage.setHistory([]);
  }

  function handleReset() {
    if (!confirm("すべてのデータをサンプルデータにリセットしますか？編集内容は失われます。")) return;
    storage.resetToSampleData();
    setFaqs(SAMPLE_FAQS);
    setClinicInfo(storage.getClinicInfo());
    setSettings(DEFAULT_SETTINGS);
    setHistory([]);
    setUnanswered([]);
    window.location.reload();
  }

  // Embed route (with or without slug)
  if (isEmbed) {
    return (
      <EmbedPage
        settings={settings}
        clinicInfo={clinicInfo}
        faqs={faqs}
        history={history}
        setHistory={setHistory}
        onUnanswered={handleUnanswered}
        onResetConversation={handleResetConversation}
      />
    );
  }

  // Admin login route
  if (hashRoute.route === "admin/login") {
    if (authLoading) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50">
          <Loader2 className="animate-spin text-sky-500" size={32} />
        </div>
      );
    }
    if (user) {
      window.location.hash = "#/admin";
      return null;
    }
    return <LoginPage onLoggedIn={() => {}} />;
  }

  // Admin route — requires auth
  if (hashRoute.route === "admin") {
    if (authLoading) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50">
          <Loader2 className="animate-spin text-sky-500" size={32} />
        </div>
      );
    }
    if (!user) {
      return <LoginPage onLoggedIn={() => {}} />;
    }
    // Clinic loading states
    if (clinicLoading && clinics.length === 0) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50">
          <Loader2 className="animate-spin text-sky-500" size={32} />
        </div>
      );
    }
    if (clinicError) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4">
          <div className="text-center max-w-sm">
            <p className="text-sm text-red-600 mb-3">{clinicError}</p>
            <button onClick={() => loadClinics()} className="rounded-lg bg-sky-600 px-4 py-2 text-sm font-semibold text-white hover:bg-sky-700">
              再読み込み
            </button>
          </div>
        </div>
      );
    }
    if (clinics.length === 0) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4">
          <div className="text-center max-w-sm">
            <Building2 size={40} className="text-slate-300 mx-auto mb-3" />
            <p className="text-sm text-slate-600 mb-1">割り当てられたクリニックがありません。</p>
            <p className="text-xs text-slate-400">管理者にクリニックの割り当てを依頼してください。</p>
            <button onClick={handleLogout} className="mt-4 rounded-lg border border-slate-200 px-4 py-2 text-sm text-slate-600 hover:bg-slate-50">
              ログアウト
            </button>
          </div>
        </div>
      );
    }
    // Clinic selector if multiple clinics and none selected
    if (clinics.length > 1 && !selectedClinic) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50 px-4">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 max-w-sm w-full">
            <h2 className="text-lg font-bold text-slate-800 mb-4">クリニックを選択</h2>
            <div className="space-y-2">
              {clinics.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setSelectedClinic(c)}
                  className="w-full flex items-center gap-3 rounded-lg border border-slate-200 px-4 py-3 text-left hover:border-sky-300 hover:bg-sky-50 transition"
                >
                  <Building2 size={18} className="text-slate-400 shrink-0" />
                  <span className="text-sm font-medium text-slate-700">{c.name}</span>
                </button>
              ))}
            </div>
            <button onClick={handleLogout} className="mt-4 w-full text-sm text-slate-500 hover:text-slate-700">
              ログアウト
            </button>
          </div>
        </div>
      );
    }
    if (!selectedClinic) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-50">
          <Loader2 className="animate-spin text-sky-500" size={32} />
        </div>
      );
    }
  }

  // If admin route and we have a selected clinic, render admin with clinic context
  const adminClinicContext = hashRoute.route === "admin" && selectedClinic ? {
    clinicId: selectedClinic.id,
    clinicSlug: selectedClinic.slug,
  } : undefined;

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top nav */}
      <nav className="bg-white border-b border-slate-200 px-4 py-2 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center bg-transparent">
          <img
            src="/images/tsunamaru/tsunamaru-transparent.png"
            alt="つなまるAI"
            className="h-10 sm:h-12 w-auto max-w-[220px] object-contain object-left"
          />
          {adminClinicContext && selectedClinic && clinics.length > 1 && (
            <div className="relative ml-2">
              <select
                value={selectedClinic.id}
                onChange={(e) => {
                  const c = clinics.find((c) => c.id === e.target.value);
                  if (c) setSelectedClinic(c);
                }}
                className="appearance-none rounded-lg border border-slate-200 pl-3 pr-8 py-1 text-xs font-medium text-slate-600 bg-white focus:outline-none focus:border-sky-400"
              >
                {clinics.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            </div>
          )}
          {adminClinicContext && (
            <button onClick={handleLogout} className="ml-1 inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs text-slate-500 hover:bg-slate-100 transition">
              <LogOut size={13} />
              <span className="hidden sm:inline">ログアウト</span>
            </button>
          )}
        </div>
        <div className="flex gap-1">
          <button
            onClick={() => setView("chat")}
            className={`focus-ring inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium transition ${
              view === "chat" ? "text-white" : "text-slate-600 hover:bg-slate-100"
            }`}
            style={view === "chat" ? { backgroundColor: settings.mainColor || "#3BA9D4" } : undefined}
          >
            <MessageCircle size={16} />
            <span className="hidden sm:inline">患者さま向けチャット</span>
          </button>
          <button
            onClick={() => setView("admin")}
            className={`focus-ring inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium transition ${
              view === "admin" ? "text-white" : "text-slate-600 hover:bg-slate-100"
            }`}
            style={view === "admin" ? { backgroundColor: settings.mainColor || "#3BA9D4" } : undefined}
          >
            <Settings size={16} />
            <span className="hidden sm:inline">管理画面</span>
          </button>
          <button
            onClick={() => setView("preview")}
            className={`focus-ring inline-flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium transition ${
              view === "preview" ? "text-white" : "text-slate-600 hover:bg-slate-100"
            }`}
            style={view === "preview" ? { backgroundColor: settings.mainColor || "#3BA9D4" } : undefined}
          >
            <Monitor size={16} />
            <span className="hidden sm:inline">サイト設置プレビュー</span>
          </button>
          <button
            onClick={startSalesDemo}
            className="focus-ring inline-flex items-center gap-1.5 rounded-lg bg-amber-500 px-3 py-1.5 text-sm font-semibold text-white transition hover:bg-amber-600 active:scale-95"
          >
            <span className="hidden sm:inline">商談デモを開始</span>
            <span className="sm:hidden">デモ</span>
          </button>
          <button
            onClick={() => setDemoSettingsOpen(true)}
            className="focus-ring inline-flex items-center gap-1.5 rounded-lg border border-amber-300 bg-amber-50 px-3 py-1.5 text-sm font-medium text-amber-700 transition hover:bg-amber-100 active:scale-95"
          >
            <span className="hidden sm:inline">商談デモ設定</span>
            <span className="sm:hidden">設定</span>
          </button>
        </div>
      </nav>

      {/* Sales demo bar */}
      {demoActive && !presentationMode && (
        <SalesDemoBar
          currentStep={demoStep}
          onStepChange={handleDemoStepChange}
          onExit={exitSalesDemo}
          demoClinicName={demoSettings.clinicName}
          onEnterPresentation={() => setPresentationMode(true)}
        />
      )}

      {/* Presentation mode */}
      {demoActive && presentationMode && (
        <PresentationMode
          currentStep={demoStep}
          onStepChange={handleDemoStepChange}
          onExit={exitPresentation}
          mainColor={demoSettings.mainColor || "#3BA9D4"}
          demoClinicName={demoSettings.clinicName}
          faqs={faqs}
          setFaqs={setFaqs}
          clinicInfo={clinicInfo}
          setClinicInfo={setClinicInfo}
          settings={settings}
          setSettings={setSettings}
          history={history}
          setHistory={setHistory}
          unanswered={unanswered}
          setUnanswered={setUnanswered}
          onReset={handleReset}
          demoClinicInfo={demoClinicInfo}
          demoSettings={demoChatSettings}
          demoLogoUrl={demoSettings.logoUrl}
          clinicSlug={adminClinicContext?.clinicSlug || "tsunamaru-test"}
        />
      )}

      {/* Sales demo settings modal */}
      {demoSettingsOpen && (
        <SalesDemoSettingsModal
          initial={demoSettings}
          realClinicInfo={clinicInfo}
          onClose={() => setDemoSettingsOpen(false)}
          onSave={saveDemoSettings}
        />
      )}

      {/* Views */}
      {view === "chat" && (
        <div className="flex-1 flex flex-col h-[calc(100vh-49px)] bg-[#f4f9fc]">
          <ChatPage
            settings={settings}
            clinicInfo={clinicInfo}
            faqs={faqs}
            history={history}
            setHistory={setHistory}
            onUnanswered={handleUnanswered}
            onResetConversation={handleResetConversation}
          />
        </div>
      )}
      {view === "preview" && (
        <SitePreviewPage
          settings={demoChatSettings}
          clinicInfo={demoClinicInfo}
          faqs={faqs}
          history={history}
          setHistory={setHistory}
          onUnanswered={handleUnanswered}
          onResetConversation={handleResetConversation}
          demoLogoUrl={demoActive ? demoSettings.logoUrl : undefined}
          clinicSlug={adminClinicContext?.clinicSlug || "tsunamaru-test"}
        />
      )}
      {view === "admin" && (
        <AdminPage
          faqs={faqs}
          setFaqs={setFaqs}
          clinicInfo={clinicInfo}
          setClinicInfo={setClinicInfo}
          settings={settings}
          setSettings={setSettings}
          history={history}
          setHistory={setHistory}
          unanswered={unanswered}
          setUnanswered={setUnanswered}
          onReset={handleReset}
          demoActive={demoActive}
          demoAdminSection={demoAdminSection}
          demoClinicInfo={demoClinicInfo}
          demoSettings={demoChatSettings}
          clinicId={adminClinicContext?.clinicId}
        />
      )}
    </div>
  );
}
