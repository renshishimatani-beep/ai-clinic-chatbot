import { useState } from "react";
import { X, Copy, RotateCcw, Save, Check, HeartPulse, Phone, CalendarPlus, FileText } from "lucide-react";
import type { ClinicInfo, SalesDemoSettings } from "@/types";
import { defaultSalesDemoSettings } from "@/services/salesDemoStorage";

export function SalesDemoSettingsModal({
  initial,
  realClinicInfo,
  onClose,
  onSave,
}: {
  initial: SalesDemoSettings;
  realClinicInfo: ClinicInfo;
  onClose: () => void;
  onSave: (s: SalesDemoSettings) => void;
}) {
  const [form, setForm] = useState<SalesDemoSettings>(initial);
  const [saved, setSaved] = useState(false);

  function update<K extends keyof SalesDemoSettings>(key: K, value: SalesDemoSettings[K]) {
    setForm((f) => ({ ...f, [key]: value }));
    setSaved(false);
  }

  function copyFromReal() {
    setForm((f) => ({
      ...f,
      clinicName: realClinicInfo.clinicName || f.clinicName,
      doctorName: realClinicInfo.doctorName || f.doctorName,
      departments: realClinicInfo.departments || f.departments,
      phone: realClinicInfo.phone || f.phone,
      address: realClinicInfo.address || f.address,
      reservationUrl: realClinicInfo.reservationUrl || f.reservationUrl,
    }));
    setSaved(false);
  }

  function resetToSample() {
    setForm(defaultSalesDemoSettings());
    setSaved(false);
  }

  function save() {
    onSave(form);
    setSaved(true);
  }

  const mainColor = form.mainColor || "#3BA9D4";

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div
        className="bg-white rounded-2xl shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-slate-100 px-5 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span
              className="inline-flex items-center justify-center w-8 h-8 rounded-lg text-white shrink-0"
              style={{ backgroundColor: mainColor }}
            >
              <HeartPulse size={16} />
            </span>
            <div>
              <h3 className="font-bold text-slate-800 text-sm">商談デモ専用設定</h3>
              <p className="text-[11px] text-amber-600">この設定は実際のクリニック情報には影響しません。</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="focus-ring rounded-lg p-1.5 text-slate-400 hover:bg-slate-100 hover:text-slate-600"
            aria-label="閉じる"
          >
            <X size={18} />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Form fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <DemoField label="商談先クリニック名">
              <input
                value={form.clinicName}
                onChange={(e) => update("clinicName", e.target.value)}
                className="focus-ring w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
              />
            </DemoField>
            <DemoField label="院長名">
              <input
                value={form.doctorName}
                onChange={(e) => update("doctorName", e.target.value)}
                className="focus-ring w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
              />
            </DemoField>
            <DemoField label="診療科">
              <input
                value={form.departments}
                onChange={(e) => update("departments", e.target.value)}
                className="focus-ring w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
              />
            </DemoField>
            <DemoField label="電話番号">
              <input
                value={form.phone}
                onChange={(e) => update("phone", e.target.value)}
                className="focus-ring w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
              />
            </DemoField>
            <DemoField label="住所" full>
              <input
                value={form.address}
                onChange={(e) => update("address", e.target.value)}
                className="focus-ring w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
              />
            </DemoField>
            <DemoField label="Web予約URL" full>
              <input
                value={form.reservationUrl}
                onChange={(e) => update("reservationUrl", e.target.value)}
                className="focus-ring w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
              />
            </DemoField>
            <DemoField label="メインカラー">
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={form.mainColor}
                  onChange={(e) => update("mainColor", e.target.value)}
                  className="h-9 w-14 rounded border border-slate-200"
                />
                <input
                  value={form.mainColor}
                  onChange={(e) => update("mainColor", e.target.value)}
                  className="focus-ring rounded-lg border border-slate-200 px-3 py-2 text-sm w-28"
                />
              </div>
            </DemoField>
            <DemoField label="ロゴ画像URL">
              <input
                value={form.logoUrl}
                onChange={(e) => update("logoUrl", e.target.value)}
                placeholder="https://…"
                className="focus-ring w-full rounded-lg border border-slate-200 px-3 py-2 text-sm"
              />
            </DemoField>
            <DemoField label="商談担当者メモ" full>
              <textarea
                value={form.salesMemo}
                onChange={(e) => update("salesMemo", e.target.value)}
                rows={2}
                placeholder="商談メモ・提案内容など"
                className="focus-ring w-full rounded-lg border border-slate-200 px-3 py-2 text-sm resize-none"
              />
            </DemoField>
          </div>

          {/* Preset buttons */}
          <div className="flex flex-wrap gap-2 pt-1">
            <button
              onClick={copyFromReal}
              className="focus-ring inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50"
            >
              <Copy size={14} />
              現在のクリニック情報をコピー
            </button>
            <button
              onClick={resetToSample}
              className="focus-ring inline-flex items-center gap-1.5 rounded-lg border border-slate-200 px-3 py-1.5 text-xs font-medium text-slate-600 hover:bg-slate-50"
            >
              <RotateCcw size={14} />
              サンプル設定に戻す
            </button>
          </div>

          {/* Live preview */}
          <div className="mt-2">
            <p className="text-xs font-semibold text-slate-500 mb-2">ライブプレビュー</p>
            <div className="rounded-xl border border-slate-200 overflow-hidden">
              {/* Clinic header preview */}
              <div className="bg-white border-b border-slate-100 px-4 py-3 flex items-center gap-2">
                {form.logoUrl ? (
                  <img
                    src={form.logoUrl}
                    alt=""
                    className="w-9 h-9 rounded-lg object-cover shrink-0"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = "none";
                    }}
                  />
                ) : (
                  <span
                    className="inline-flex items-center justify-center w-9 h-9 rounded-xl text-white shrink-0"
                    style={{ backgroundColor: mainColor }}
                  >
                    <HeartPulse size={18} />
                  </span>
                )}
                <div className="min-w-0 flex-1">
                  <p className="font-bold text-slate-800 text-sm truncate">
                    {form.clinicName || "クリニック名"}
                  </p>
                  <p className="text-[10px] text-slate-400 truncate">
                    {form.departments || "診療科"}
                  </p>
                </div>
                <a
                  href={form.reservationUrl || "#"}
                  onClick={(e) => e.preventDefault()}
                  className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-semibold text-white shrink-0"
                  style={{ backgroundColor: mainColor }}
                >
                  <CalendarPlus size={14} />
                  Web予約
                </a>
              </div>

              {/* Launcher preview */}
              <div className="bg-slate-50 px-4 py-4 flex items-center justify-end">
                <div
                  className="flex items-center gap-2 rounded-full bg-transparent pl-2 pr-4 py-2"
                >
                  <img
                    src="/images/tsunamaru/tsunamaru-transparent.png"
                    alt=""
                    className="w-9 h-9 rounded-full object-contain object-center bg-transparent"
                    draggable={false}
                  />
                  <span className="text-sm font-semibold" style={{ color: mainColor }}>
                    つなまるAIに質問
                  </span>
                </div>
              </div>

              {/* Report header preview */}
              <div className="bg-white px-4 py-3 border-t border-slate-100">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="text-xs text-slate-500">{form.clinicName || "クリニック名"}</p>
                    <div className="flex items-center gap-1.5 mt-1">
                      <FileText size={14} style={{ color: mainColor }} />
                      <p className="text-sm font-bold text-slate-800">つなまるAI 月次分析レポート</p>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {form.doctorName && `${form.doctorName}｜`}{form.departments}
                    </p>
                  </div>
                  <span
                    className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[10px] font-semibold"
                    style={{ backgroundColor: `${mainColor}15`, color: mainColor }}
                  >
                    <Phone size={11} />
                    {form.phone || "電話番号"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-white border-t border-slate-100 px-5 py-3 flex items-center justify-end gap-2">
          <button
            onClick={onClose}
            className="focus-ring rounded-lg px-4 py-2 text-sm text-slate-600 hover:bg-slate-100"
          >
            キャンセル
          </button>
          <button
            onClick={save}
            className="focus-ring inline-flex items-center gap-1.5 rounded-lg bg-sky-500 px-4 py-2 text-sm font-semibold text-white hover:bg-sky-600"
          >
            {saved ? <Check size={16} /> : <Save size={16} />}
            設定を保存
          </button>
        </div>
      </div>
    </div>
  );
}

function DemoField({
  label,
  children,
  full,
}: {
  label: string;
  children: React.ReactNode;
  full?: boolean;
}) {
  return (
    <div className={full ? "sm:col-span-2" : ""}>
      <label className="block text-xs font-medium text-slate-500 mb-1">{label}</label>
      {children}
    </div>
  );
}
