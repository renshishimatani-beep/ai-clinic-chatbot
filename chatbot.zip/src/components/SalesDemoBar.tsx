import { ChevronLeft, ChevronRight, XCircle, Presentation } from "lucide-react";

const DEMO_STEPS = [
  {
    label: "① ダッシュボード",
    explanation:
      "24時間対応による問い合わせ対応数と、休診時間の機会損失防止を確認できます。",
  },
  {
    label: "② 問い合わせ分析",
    explanation:
      "いつ・どのような問い合わせが来ているかを年・月別に分析できます。",
  },
  {
    label: "③ 月次レポート",
    explanation:
      "毎月の患者ニーズと改善提案を、医院さまへレポートとして共有できます。",
  },
  {
    label: "④ サイト設置プレビュー",
    explanation: "実際の医院ホームページに設置した際の利用イメージです。",
  },
];

export function SalesDemoBar({
  currentStep,
  onStepChange,
  onExit,
  demoClinicName,
  onEnterPresentation,
}: {
  currentStep: number;
  onStepChange: (step: number) => void;
  onExit: () => void;
  demoClinicName?: string;
  onEnterPresentation?: () => void;
}) {
  return (
    <div className="no-print sticky top-[49px] z-10 bg-sky-600 text-white shadow-md">
      <div className="px-4 py-2">
        <div className="flex items-center gap-2 flex-wrap">
          {/* Step buttons */}
          <div className="flex items-center gap-1">
            {DEMO_STEPS.map((step, i) => (
              <button
                key={i}
                onClick={() => onStepChange(i)}
                className={`text-xs font-medium rounded-full px-2.5 py-1 transition whitespace-nowrap ${
                  currentStep === i
                    ? "bg-white text-sky-700"
                    : "bg-sky-500/50 text-sky-100 hover:bg-sky-500"
                }`}
              >
                {step.label}
              </button>
            ))}
          </div>

          <div className="flex-1" />

          {/* Demo clinic name */}
          {demoClinicName && (
            <span className="text-xs font-semibold text-white/90 truncate max-w-[40vw]">
              {demoClinicName}
            </span>
          )}

          {/* Demo data badge */}
          <span className="text-[11px] font-semibold bg-white/20 rounded-full px-2.5 py-0.5 whitespace-nowrap">
            デモデータ｜運用後イメージ
          </span>

          {/* Nav buttons */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => onStepChange(Math.max(0, currentStep - 1))}
              disabled={currentStep === 0}
              className="inline-flex items-center gap-1 text-xs font-medium rounded-lg bg-sky-500/50 hover:bg-sky-500 disabled:opacity-40 disabled:cursor-not-allowed px-2.5 py-1 transition whitespace-nowrap"
            >
              <ChevronLeft size={14} />
              前の画面
            </button>
            <button
              onClick={() => onStepChange(Math.min(3, currentStep + 1))}
              disabled={currentStep === 3}
              className="inline-flex items-center gap-1 text-xs font-semibold rounded-lg bg-white text-sky-700 hover:bg-sky-50 disabled:opacity-40 disabled:cursor-not-allowed px-2.5 py-1 transition whitespace-nowrap"
            >
              次の画面
              <ChevronRight size={14} />
            </button>
            <button
              onClick={onExit}
              className="inline-flex items-center gap-1 text-xs font-medium rounded-lg bg-sky-500/50 hover:bg-red-500 px-2.5 py-1 transition whitespace-nowrap"
            >
              <XCircle size={14} />
              商談デモを終了
            </button>
            {onEnterPresentation && (
              <button
                onClick={onEnterPresentation}
                className="inline-flex items-center gap-1 text-xs font-semibold rounded-lg bg-white/20 hover:bg-white/30 px-2.5 py-1 transition whitespace-nowrap"
              >
                <Presentation size={14} />
                全画面プレゼン
              </button>
            )}
          </div>
        </div>

        {/* Explanation */}
        <p className="text-xs text-sky-100 mt-1.5 leading-relaxed">
          {DEMO_STEPS[currentStep].explanation}
        </p>
      </div>
    </div>
  );
}
