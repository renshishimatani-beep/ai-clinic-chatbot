import { useEffect, useState, useCallback } from "react";
import {
  ChevronLeft,
  ChevronRight,
  XCircle,
  Maximize,
  Minimize,
  Eye,
  EyeOff,
  Presentation,
} from "lucide-react";
import type { ClinicInfo, ChatSettings, FAQ, ChatMessage, UnansweredQuestion } from "@/types";
import { AdminPage } from "@/pages/AdminPage";
import { SitePreviewPage } from "@/pages/SitePreviewPage";

export type DemoSection = "dashboard" | "analytics" | "report";

const PRESENTATION_STEPS = [
  {
    label: "ダッシュボード",
    section: "dashboard" as DemoSection,
    note: "問い合わせ総数、AI回答率、休診時間の問い合わせを確認し、24時間対応の効果を説明します。",
  },
  {
    label: "問い合わせ分析",
    section: "analytics" as DemoSection,
    note: "患者さまが、いつ・何を求めて問い合わせているのかを年・月別に確認します。",
  },
  {
    label: "月次レポート",
    section: "report" as DemoSection,
    note: "運用結果だけでなく、毎月の改善提案まで医院さまへ共有できることを説明します。",
  },
  {
    label: "サイト設置プレビュー",
    section: null,
    note: "実際の医院ホームページ上で、患者さまがどのように利用するかをご覧いただきます。",
  },
];

export function PresentationMode({
  currentStep,
  onStepChange,
  onExit,
  mainColor,
  demoClinicName,
  faqs,
  setFaqs,
  clinicInfo,
  setClinicInfo,
  settings,
  setSettings,
  history,
  setHistory,
  unanswered,
  setUnanswered,
  onReset,
  demoClinicInfo,
  demoSettings,
  demoLogoUrl,
  clinicSlug,
}: {
  currentStep: number;
  onStepChange: (step: number) => void;
  onExit: () => void;
  mainColor: string;
  demoClinicName: string;
  faqs: FAQ[];
  setFaqs: (f: FAQ[]) => void;
  clinicInfo: ClinicInfo;
  setClinicInfo: (c: ClinicInfo) => void;
  settings: ChatSettings;
  setSettings: (s: ChatSettings) => void;
  history: ChatMessage[];
  setHistory: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
  unanswered: UnansweredQuestion[];
  setUnanswered: (u: UnansweredQuestion[]) => void;
  onReset: () => void;
  demoClinicInfo: ClinicInfo;
  demoSettings: ChatSettings;
  demoLogoUrl?: string;
  clinicSlug?: string;
}) {
  const [showNotes, setShowNotes] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const step = PRESENTATION_STEPS[currentStep];
  const isPreviewStep = currentStep === 3;

  const goNext = useCallback(() => {
    onStepChange(Math.min(3, currentStep + 1));
  }, [currentStep, onStepChange]);

  const goPrev = useCallback(() => {
    onStepChange(Math.max(0, currentStep - 1));
  }, [currentStep, onStepChange]);

  // Keyboard navigation
  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      const target = e.target as HTMLElement;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.tagName === "SELECT")) {
        return;
      }
      if (e.key === "ArrowRight") {
        e.preventDefault();
        goNext();
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        goPrev();
      } else if (e.key === "Escape") {
        e.preventDefault();
        onExit();
      }
    }
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [goNext, goPrev, onExit]);

  // Track fullscreen state
  useEffect(() => {
    function onFsChange() {
      setIsFullscreen(Boolean(document.fullscreenElement));
    }
    document.addEventListener("fullscreenchange", onFsChange);
    return () => document.removeEventListener("fullscreenchange", onFsChange);
  }, []);

  function toggleFullscreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen?.().catch(() => {
        /* fullscreen unavailable — stay in presentation layout */
      });
    } else {
      document.exitFullscreen?.().catch(() => {
        /* ignore */
      });
    }
  }

  const progressPct = ((currentStep + 1) / PRESENTATION_STEPS.length) * 100;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900 flex flex-col overflow-hidden">
      {/* ── Presentation top bar ── */}
      <div className="no-print shrink-0 bg-slate-800 text-white px-4 py-2.5 flex items-center gap-3 flex-wrap border-b border-slate-700">
        {/* Brand + clinic name */}
        <div className="flex items-center gap-2 min-w-0">
          <span
            className="inline-flex items-center justify-center w-7 h-7 rounded-lg text-white text-xs font-bold shrink-0"
            style={{ backgroundColor: mainColor }}
          >
            <Presentation size={14} />
          </span>
          <span className="text-sm font-bold truncate max-w-[30vw]">{demoClinicName}</span>
        </div>

        {/* Demo badge */}
        <span className="text-[11px] font-semibold bg-white/15 rounded-full px-2.5 py-0.5 whitespace-nowrap">
          デモデータ｜運用後イメージ
        </span>

        <div className="flex-1" />

        {/* Step title */}
        <span className="text-sm font-semibold text-slate-200 hidden sm:inline">
          {step.label}
        </span>

        {/* Progress */}
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-300 tabular-nums">
            {currentStep + 1} / {PRESENTATION_STEPS.length}
          </span>
          <div className="w-20 h-1.5 rounded-full bg-slate-600 overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-300"
              style={{ width: `${progressPct}%`, backgroundColor: mainColor }}
            />
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-1">
          <button
            onClick={goPrev}
            disabled={currentStep === 0}
            className="inline-flex items-center gap-1 text-xs font-medium rounded-lg bg-slate-700 hover:bg-slate-600 disabled:opacity-40 disabled:cursor-not-allowed px-2.5 py-1.5 transition whitespace-nowrap"
          >
            <ChevronLeft size={14} />
            前へ
          </button>
          <button
            onClick={goNext}
            disabled={currentStep === 3}
            className="inline-flex items-center gap-1 text-xs font-semibold rounded-lg px-2.5 py-1.5 transition whitespace-nowrap disabled:opacity-40 disabled:cursor-not-allowed"
            style={{ backgroundColor: mainColor }}
          >
            次へ
            <ChevronRight size={14} />
          </button>
          <button
            onClick={onExit}
            className="inline-flex items-center gap-1 text-xs font-medium rounded-lg bg-slate-700 hover:bg-red-600 px-2.5 py-1.5 transition whitespace-nowrap"
          >
            <XCircle size={14} />
            プレゼンを終了
          </button>
          <button
            onClick={toggleFullscreen}
            className="inline-flex items-center gap-1 text-xs font-medium rounded-lg bg-slate-700 hover:bg-slate-600 px-2.5 py-1.5 transition whitespace-nowrap"
            title={isFullscreen ? "全画面を終了" : "ブラウザ全画面"}
          >
            {isFullscreen ? <Minimize size={14} /> : <Maximize size={14} />}
            <span className="hidden sm:inline">{isFullscreen ? "全画面を終了" : "ブラウザ全画面"}</span>
          </button>
          <button
            onClick={() => setShowNotes((v) => !v)}
            className="inline-flex items-center gap-1 text-xs font-medium rounded-lg bg-slate-700 hover:bg-slate-600 px-2.5 py-1.5 transition whitespace-nowrap"
            title="説明メモの表示切替"
          >
            {showNotes ? <EyeOff size={14} /> : <Eye size={14} />}
            <span className="hidden sm:inline">説明メモを表示</span>
          </button>
        </div>
      </div>

      {/* ── Presenter note card ── */}
      {showNotes && (
        <div className="no-print shrink-0 bg-amber-50 border-b border-amber-200 px-4 py-2 flex items-start gap-2">
          <span
            className="inline-flex items-center justify-center w-6 h-6 rounded-full text-white text-xs font-bold shrink-0 mt-0.5"
            style={{ backgroundColor: mainColor }}
          >
            {currentStep + 1}
          </span>
          <div>
            <p className="text-xs font-bold text-amber-700">プレゼンメモ — {step.label}</p>
            <p className="text-sm text-amber-800 leading-relaxed">{step.note}</p>
          </div>
        </div>
      )}

      {/* ── Content area ── */}
      <div className="flex-1 overflow-auto bg-slate-50 presentation-content">
        {isPreviewStep ? (
          <SitePreviewPage
            settings={demoSettings}
            clinicInfo={demoClinicInfo}
            faqs={faqs}
            history={history}
            setHistory={setHistory}
            onUnanswered={() => {}}
            onResetConversation={() => {}}
            demoLogoUrl={demoLogoUrl}
            clinicSlug={clinicSlug}
          />
        ) : (
          <AdminPage
            faqs={faqs}
            setFaqs={setFaqs}
            clinicInfo={clinicInfo}
            setClinicInfo={setClinicInfo}
            settings={settings}
            setSettings={setSettings}
            history={history}
            setHistory={setHistory}
            unanswered={unanswered}
            setUnanswered={setUnanswered}
            onReset={onReset}
            demoActive
            demoAdminSection={step.section ?? "dashboard"}
            demoClinicInfo={demoClinicInfo}
            demoSettings={demoSettings}
            presentationMode
          />
        )}
      </div>
    </div>
  );
}
