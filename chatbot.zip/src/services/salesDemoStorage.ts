import type { SalesDemoSettings } from "@/types";

const KEY = "tsunamaru_sales_demo_settings";

const DEFAULT_DEMO_SETTINGS: SalesDemoSettings = {
  clinicName: "みなと海浜クリニック",
  doctorName: "港 太郎",
  departments: "内科・小児科",
  phone: "03-1234-5678",
  address: "東京都港区海岸1-2-3",
  reservationUrl: "https://example.com/reservation",
  mainColor: "#3BA9D4",
  logoUrl: "",
  salesMemo: "",
};

export function getSalesDemoSettings(): SalesDemoSettings {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_DEMO_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<SalesDemoSettings>;
    return { ...DEFAULT_DEMO_SETTINGS, ...parsed };
  } catch {
    return DEFAULT_DEMO_SETTINGS;
  }
}

export function setSalesDemoSettings(settings: SalesDemoSettings): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(settings));
  } catch {
    /* ignore quota errors */
  }
}

export function defaultSalesDemoSettings(): SalesDemoSettings {
  return { ...DEFAULT_DEMO_SETTINGS };
}
