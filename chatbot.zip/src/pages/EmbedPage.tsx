import { useEffect, useState } from "react";
import type { ChatMessage, ChatSettings, ClinicInfo, FAQ } from "@/types";
import { ChatPage } from "@/pages/ChatPage";

export function EmbedPage({
  settings,
  clinicInfo,
  faqs,
  history,
  setHistory,
  onUnanswered,
  onResetConversation,
}: {
  settings: ChatSettings;
  clinicInfo: ClinicInfo;
  faqs: FAQ[];
  history: ChatMessage[];
  setHistory: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
  onUnanswered: (question: string) => void;
  onResetConversation: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [imgVisible, setImgVisible] = useState(true);
  const mainColor = settings.mainColor || "#3BA9D4";

  useEffect(() => {
    document.documentElement.style.background = "transparent";
    document.body.style.background = "transparent";
  }, []);

  useEffect(() => {
    if (!open) return;
    const mq = window.matchMedia("(max-width: 639px)");
    const apply = () => {
      document.body.style.overflow = mq.matches ? "hidden" : "";
    };
    apply();
    mq.addEventListener("change", apply);
    return () => {
      mq.removeEventListener("change", apply);
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <div className="fixed inset-0" style={{ background: "transparent" }}>
      {!open && (
        <button
          onClick={() => setOpen(true)}
          className="fixed bottom-4 right-4 z-40 flex items-center gap-2 rounded-full bg-transparent pl-2 pr-4 py-2 launcher-float transition-shadow"
          aria-label="つなまるAIに質問"
        >
          {imgVisible && (
            <img
              src="/images/tsunamaru/tsunamaru-transparent.png"
              onError={() => setImgVisible(false)}
              alt="つなまるAI"
              className="w-10 h-10 rounded-full object-contain object-center bg-transparent"
              draggable={false}
            />
          )}
          <span className="text-sm font-semibold" style={{ color: mainColor }}>
            つなまるAIに質問
          </span>
        </button>
      )}

      {open && (
        <div className="fixed inset-0 sm:inset-auto sm:bottom-24 sm:right-4 z-50 flex flex-col overflow-hidden bg-white shadow-2xl sm:rounded-2xl sm:w-[400px] sm:h-[680px]">
          <ChatPage
            settings={settings}
            clinicInfo={clinicInfo}
            faqs={faqs}
            history={history}
            setHistory={setHistory}
            onUnanswered={onUnanswered}
            onResetConversation={onResetConversation}
            widgetMode
            onClose={() => setOpen(false)}
          />
        </div>
      )}
    </div>
  );
}
